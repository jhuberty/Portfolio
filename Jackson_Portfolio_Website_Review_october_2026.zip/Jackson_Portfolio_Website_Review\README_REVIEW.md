# Portfolio Website Review Snapshot

## Purpose

This is a read-only review snapshot of the Jackson Huberty Engineering Portfolio website. It preserves the source structure and relative paths required to run the static site locally.

## Architecture

This is a static website with no build step, package manager, framework, or server-side code.

- `index.html` is the homepage.
- `projects/` contains detailed project pages.
- `styles.css` provides site styling and responsive layout rules.
- `script.js` provides mobile navigation and image-lightbox interactions.
- `assets/images/` contains project and profile images organized by subject.
- `resume/Jackson_Huberty_Resume.pdf` is the locally linked resume.
- `README.md` is the repository documentation.

## Run Locally

1. Extract this ZIP while keeping the included folder structure intact.
2. Open `index.html` in a web browser.

Optional local server:

```powershell
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Site Paths

Homepage:

- `index.html`

Detailed project pages:

- `projects/quarter-scale.html`
- `projects/agave-harvester.html`
- `projects/machining.html`
- `projects/agricultural-equipment.html`

## Build Dependencies

None. The website uses only HTML, CSS, and vanilla JavaScript. No Node.js modules, package files, build output, or framework tooling are required.

## Quarter Scale Tractor: Preliminary Structural Analysis

Location: `projects/quarter-scale.html`

Heading: `Preliminary Structural Analysis`

Text:

> I created an initial static simulation of a Quarter Scale Tractor frame rail to establish a representative loading and support condition for structural evaluation. This Version 1 model will be refined as the frame design, loading assumptions, and mounting conditions are finalized.

Image path:

- `assets/images/quarter-scale/quarter-scale-frame-rail-v1-simulation.png`

Image alt text:

- `Preliminary SolidWorks static simulation of a Quarter Scale Tractor frame rail with applied loads and support conditions.`

Caption:

- `Version 1 static structural simulation setup for a Quarter Scale Tractor frame rail.`

This snapshot does not move or modify this section or its image.

## Agave Harvester Project

Project page: `projects/agave-harvester.html`

The page currently contains these locally stored project images and captions:

- `assets/images/agave-harvester/grape-harvester-platform.jpg` — Existing grape-harvester platform being adapted for the agave-harvester senior project.
- `assets/images/agave-harvester/agave-blade-beam-cad.png` — SolidWorks model of the Agave Harvester chopping-head structure and blade-beam assembly under development.

Both images use the site’s existing image-lightbox behavior where configured by the page markup and `script.js`.

## Assets and External Resources

All runtime images, stylesheets, scripts, and the resume included by this website are stored locally in this snapshot. There are no externally hosted runtime assets to download.

The site includes normal outbound profile links, including:

- https://www.linkedin.com/in/jackson-huberty/
- https://github.com/jhuberty

## Snapshot Scope

Included: website source, project pages, CSS, JavaScript, locally stored images, resume assets, and documentation.

Excluded: `.git`, `node_modules`, caches, temporary files, credentials, environment files, and other generated or unnecessary files.